# Lumina Haven Ltd. Landing Page (Next.js + Tailwind)

## Run locally
```bash
npm install
npm run dev
```

## Deploy on Vercel
Import this repo in Vercel. It will auto-detect Next.js.

## Images
Replace placeholder images in `public/images/`:
- hero.jpg
- p1.jpg ... p6.jpg
