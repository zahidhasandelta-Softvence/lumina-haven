import "./globals.css";

export const metadata = {
  title: "Lumina Haven Ltd. | Decorative Home Lighting",
  description: "A simple landing page for Lumina Haven Ltd. decorative lighting collection."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
