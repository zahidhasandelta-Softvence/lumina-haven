export default function Contact() {
  return (
    <section id="contact" className="mx-auto max-w-5xl px-4 py-12">
      <div className="rounded-2xl border border-zinc-200 bg-zinc-900 p-6 text-white md:p-10">
        <div className="grid gap-8 md:grid-cols-2 md:items-center">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Contact & Visit</h2>
            <p className="mt-3 text-white/80">
              Want to check stock or get a quick recommendation? Call us and we’ll help you choose the right light.
            </p>

            <div className="mt-6 space-y-3 text-sm">
              <div className="flex flex-col">
                <span className="text-white/70">Telephone</span>
                <a className="font-medium hover:underline" href="tel:+15554827391">
                  +1 (555) 482-7391
                </a>
              </div>
              <div className="flex flex-col">
                <span className="text-white/70">Address</span>
                <span className="font-medium">House 42, Willow Lane</span>
              </div>
            </div>

            <div className="mt-7 flex flex-wrap gap-3">
              <a
                href="tel:+15554827391"
                className="rounded-lg bg-white px-4 py-2.5 text-sm font-semibold text-zinc-900 hover:bg-zinc-100"
              >
                Call Now
              </a>
              <a
                href="#products"
                className="rounded-lg border border-white/25 px-4 py-2.5 text-sm font-medium hover:bg-white/10"
              >
                Browse Products
              </a>
            </div>
          </div>

          <div className="rounded-2xl bg-white/10 p-5">
            <h3 className="text-base font-semibold">Quick Note</h3>
            <p className="mt-2 text-sm text-white/80">
              This is a simple landing page. If you later want a full catalog, WhatsApp button, or online ordering,
              this project can be expanded without rebuilding everything.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
