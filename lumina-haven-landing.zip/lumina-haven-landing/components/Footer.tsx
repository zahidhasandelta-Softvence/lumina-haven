export default function Footer() {
  return (
    <footer className="border-t border-zinc-200">
      <div className="mx-auto flex max-w-5xl flex-col gap-2 px-4 py-8 text-sm text-zinc-600 md:flex-row md:items-center md:justify-between">
        <p>© {new Date().getFullYear()} Lumina Haven Ltd. All rights reserved.</p>
        <div className="flex gap-4">
          <a className="hover:underline" href="#about">About</a>
          <a className="hover:underline" href="#products">Products</a>
          <a className="hover:underline" href="#contact">Contact</a>
        </div>
      </div>
    </footer>
  );
}
