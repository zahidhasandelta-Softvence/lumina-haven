export default function About() {
  return (
    <section id="about" className="mx-auto max-w-5xl px-4 py-12">
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">About Us</h2>
          <p className="mt-4 text-zinc-600">
            Lumina Haven Ltd. is a local home decor lighting shop focused on warm ambience and clean design.
            We help customers find decorative lights that feel premium and inviting, without overcomplicating the setup.
          </p>
          <p className="mt-3 text-zinc-600">
            Whether you’re styling a bedroom, living room, or a small reading nook, we’ll help you pick the right glow.
          </p>
        </div>

        <div className="rounded-2xl border border-zinc-200 bg-zinc-50 p-6">
          <h3 className="text-base font-semibold">What you’ll find here</h3>
          <ul className="mt-4 space-y-3 text-zinc-700">
            <li className="flex gap-2">
              <span className="mt-1 h-2 w-2 rounded-full bg-zinc-900" />
              Table lamps, wall lights, and decorative pieces
            </li>
            <li className="flex gap-2">
              <span className="mt-1 h-2 w-2 rounded-full bg-zinc-900" />
              Cozy, modern styles that fit most interiors
            </li>
            <li className="flex gap-2">
              <span className="mt-1 h-2 w-2 rounded-full bg-zinc-900" />
              Friendly local support and quick recommendations
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
