import Image from "next/image";

export default function Hero() {
  return (
    <section id="top" className="border-b border-zinc-200">
      <div className="mx-auto grid max-w-5xl items-center gap-8 px-4 py-12 md:grid-cols-2 md:py-16">
        <div>
          <p className="text-sm font-medium text-zinc-600">Decorative Home Lighting</p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight md:text-4xl">
            Light up your space with warm, modern decor pieces.
          </h1>
          <p className="mt-4 text-zinc-600">
            Lumina Haven Ltd. offers a curated selection of decorative lights for cozy corners,
            statement walls, and everyday comfort.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="#products"
              className="rounded-lg bg-zinc-900 px-4 py-2.5 text-sm font-medium text-white hover:bg-zinc-800"
            >
              Browse Collection
            </a>
            <a
              href="#contact"
              className="rounded-lg border border-zinc-300 px-4 py-2.5 text-sm font-medium hover:bg-zinc-50"
            >
              Visit & Contact
            </a>
          </div>

          <div className="mt-6 flex flex-wrap gap-4 text-sm text-zinc-600">
            <span className="rounded-full border border-zinc-200 px-3 py-1">Fast loading</span>
            <span className="rounded-full border border-zinc-200 px-3 py-1">Mobile-friendly</span>
            <span className="rounded-full border border-zinc-200 px-3 py-1">Local shop</span>
          </div>
        </div>

        <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-zinc-200 bg-zinc-100">
          <Image
            src="/images/hero.jpg"
            alt="Decorative lighting showcase"
            fill
            priority
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 50vw"
          />
        </div>
      </div>
    </section>
  );
}
