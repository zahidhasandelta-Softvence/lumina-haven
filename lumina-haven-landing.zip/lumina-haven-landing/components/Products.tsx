"use client";

import Image from "next/image";
import { useMemo, useState } from "react";

type Product = {
  id: string;
  name: string;
  image: string;
  tag: string;
};

const PRODUCTS: Product[] = [
  { id: "p1", name: "Warm Glow Table Lamp", image: "/images/p1.jpg", tag: "Cozy" },
  { id: "p2", name: "Minimalist Wall Sconce", image: "/images/p2.jpg", tag: "Modern" },
  { id: "p3", name: "Soft Ambient Night Light", image: "/images/p3.jpg", tag: "Relax" },
  { id: "p4", name: "Statement Pendant Light", image: "/images/p4.jpg", tag: "Feature" },
  { id: "p5", name: "Vintage Edison Lamp", image: "/images/p5.jpg", tag: "Classic" },
  { id: "p6", name: "Compact Desk Lamp", image: "/images/p6.jpg", tag: "Work" }
];

export default function Products() {
  const [expanded, setExpanded] = useState(false);

  const visibleProducts = useMemo(() => {
    if (expanded) return PRODUCTS;
    return PRODUCTS.slice(0, 6);
  }, [expanded]);

  return (
    <section id="products" className="border-y border-zinc-200 bg-zinc-50">
      <div className="mx-auto max-w-5xl px-4 py-12">
        <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Browse Products</h2>
            <p className="mt-2 text-zinc-600">
              A simple preview of popular decorative lights. No online checkout yet, just browse and call.
            </p>
          </div>

          <a
            href="tel:+15554827391"
            className="mt-4 inline-flex w-fit rounded-lg bg-zinc-900 px-4 py-2.5 text-sm font-medium text-white hover:bg-zinc-800 md:mt-0"
          >
            Call to Ask Availability
          </a>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 md:grid-cols-3">
          {visibleProducts.map((p) => (
            <div
              key={p.id}
              className="overflow-hidden rounded-2xl border border-zinc-200 bg-white"
            >
              <div className="relative aspect-[4/3] bg-zinc-100">
                <Image
                  src={p.image}
                  alt={p.name}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-base font-semibold">{p.name}</h3>
                  <span className="rounded-full border border-zinc-200 px-2 py-1 text-xs text-zinc-700">
                    {p.tag}
                  </span>
                </div>
                <p className="mt-2 text-sm text-zinc-600">
                  Call for pricing and in-store availability.
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex justify-center">
          <button
            onClick={() => setExpanded((v) => !v)}
            className="rounded-lg border border-zinc-300 bg-white px-5 py-2.5 text-sm font-medium hover:bg-zinc-100"
            aria-expanded={expanded}
          >
            {expanded ? "View Less" : "View More"}
          </button>
        </div>
      </div>
    </section>
  );
}
