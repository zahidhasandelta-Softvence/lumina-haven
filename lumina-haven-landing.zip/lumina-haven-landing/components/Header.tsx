export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-zinc-200 bg-white/80 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
        <a href="#top" className="font-semibold tracking-tight">
          Lumina Haven Ltd.
        </a>

        <nav className="hidden gap-6 text-sm md:flex">
          <a className="hover:underline" href="#about">About</a>
          <a className="hover:underline" href="#products">Browse Products</a>
          <a className="hover:underline" href="#contact">Contact</a>
        </nav>

        <a
          href="tel:+15554827391"
          className="rounded-lg bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-800"
        >
          Call Now
        </a>
      </div>
    </header>
  );
}
